import numpy as np
from enum import Enum
import collections
import itertools

MESSAGE_STX = 0xFA
MESSAGE_END = 0xA501EDF4
MIN_MESSAGE_LENGTH = 10
IMAGE_CHUNK_SIZE = 2048
MAX_PAYLOAD_LENGTH = IMAGE_CHUNK_SIZE + 8
MAX_MESSAGE_LENGTH = 10 + MAX_PAYLOAD_LENGTH

class MessageType(Enum):
    UNDEFINED = 0x00
    IMAGE_META = 0x01
    IMAGE = 0x02
    RESET_RECEIVER = 0x03
    CLOSE_STREAM = 0xFF

class ImagePayloadDecoder:
    def __init__(self, payload:bytes) -> None:
        self.image_id = int.from_bytes(payload[:4], byteorder='little')
        self.chunk_id = int.from_bytes(payload[4:8], byteorder='little')
        self.image = np.frombuffer(payload[8:], dtype=np.uint8)
        pass

class ImageMetaPayloadDecoder:
    def __init__(self, payload:bytes) -> None:
        self.image_id = int.from_bytes(payload[0:4], byteorder='little')
        self.image_width = int.from_bytes(payload[4:6], byteorder='little')
        self.image_hight = int.from_bytes(payload[6:8], byteorder='little')
        self.package_total_number = int.from_bytes(payload[8:12], byteorder='little')
        self.package_size = int.from_bytes(payload[12:16], byteorder='little')
        pass

class Message:

    is_message_found = False

    def __init__(self) -> None:
        self.stx = 0
        self.messageType = MessageType.UNDEFINED
        self.payload_length = 0
        self.payload = None
        self.message_end_mark = 0
        pass

    def get_message_type(self):
        return self.messageType

    def find_message(self, input_buffer:collections.deque):
        input_buffer_len = len(input_buffer)
        for item in range(input_buffer_len):
            value = input_buffer.popleft()
            if value == MESSAGE_STX:
                input_buffer.appendleft(value)
                break
            
        if len(input_buffer) >= MIN_MESSAGE_LENGTH:
            self.decode_header(input_buffer)
            if self.messageType is not MessageType.UNDEFINED:
                # this means we have found header part of the message
                # let's check end of message value
                if self.payload_length <= MAX_PAYLOAD_LENGTH:
                    if len(input_buffer) >= (1+1+4+self.payload_length+4):
                        end_of_message_slice = list(itertools.islice(input_buffer, 6 + self.payload_length, 6 + self.payload_length + 4))
                        end_of_message = int.from_bytes(end_of_message_slice, byteorder='little')
                        if end_of_message == MESSAGE_END:
                            # the message is found
                            self.message_end_mark = MESSAGE_END
                            self.is_message_found = True
                            self.payload = bytes(list(itertools.islice(input_buffer, 6, 6 + self.payload_length)))
                            # clean buffer
                            for item in range(1 + 1 + 4 + self.payload_length + 4):
                                input_buffer.popleft()
                        else:
                            # this is not the message
                            # remode current found byte as trash
                            input_buffer.popleft()
                            pass
                    else:
                        # not a full message
                        # skip for future analysis
                        pass
                else:
                    # this is not the message,
                    # remode current found byte as trash
                    input_buffer.popleft()
                    pass
            else:
                # this means we have found wrong start of the message
                # remove current found byte as trash
                input_buffer.popleft()
                pass
        else:
            # buffer is empty. nothing to do.
            pass
        pass

    def decode_header(self, input_buffer:collections.deque):
        self.stx = input_buffer[0]
        try:
            self.messageType = MessageType(input_buffer[1])
        except:
            self.messageType = MessageType.UNDEFINED

        self.payload_length = int.from_bytes(list(itertools.islice(input_buffer, 2, 6)), byteorder='little')
        