import sys
import serial
import serial.tools.list_ports
from typing import List
import threading
import numpy as np
import collections
import cv2
import datetime
import queue

import datetime

from message_decoder import Message, ImagePayloadDecoder, ImageMetaPayloadDecoder, MessageType
from message_decoder import MIN_MESSAGE_LENGTH

SUPPORTED_DEVICES = ["0403:6001", "0483:5740"]

IMAGE_WIDTH = 600
IMAGE_HIGHT = 400
INPUT_BUFFER_SIZE = IMAGE_WIDTH * IMAGE_HIGHT * 5

class PerformanceTimer():

    def __init__(self, stream_id:str) -> None:
        self.start_timemark = 0
        self.stream_id = stream_id

    def start_timer(self):
        self.start_timemark = datetime.datetime.now()

    def show_timer(self, mark:str=""):
        current_timemark = datetime.datetime.now()
        if mark == "":
            print(f"{self.stream_id}: {current_timemark}: dt = {current_timemark - self.start_timemark}")
        else:
            print(f"{self.stream_id}: {current_timemark}:  dt = {current_timemark - self.start_timemark} -> {mark}")

    def stop_timer(self):
        end_timemark = datetime.datetime.now()
        print(f"{self.stream_id}: {end_timemark} dt = {end_timemark - self.start_timemark}")

class Image:
    def __init__(self) -> None:
        self.id = 0
        self.width = 0
        self.hight = 0
        self.chunk_size = 0
        self.total_chunk_number = 0
        self.parts = dict()
        pass

    def add_chunk(self, chunk_id, image):
        self.parts[chunk_id] = image.copy()
        pass

    def clear(self):
        self.parts = dict()
        pass

    def get_image(self):
        binary_frame = list()
        available_chunks = self.parts.keys()
        for chunk in range(0, self.total_chunk_number):
            if chunk in available_chunks:
                binary_frame = [*binary_frame, *self.parts[chunk]]
            else:
                empty_pixels = None
                if chunk == self.total_chunk_number - 1:
                    empty_pixels = [0] * ((self.hight*self.width) % self.chunk_size)
                else:
                    empty_pixels = [0] * self.chunk_size
                    pass
                binary_frame = [*binary_frame, *empty_pixels]
                pass
            pass
        frame = np.array(binary_frame).reshape(self.hight, self.width).astype(np.uint8)
        return frame

def get_system_ports()-> List:
    return serial.tools.list_ports.comports()

def get_supported_port(ports:List) -> str:
    supported_port_name = ""
    for port in ports:
        for supoored_port in SUPPORTED_DEVICES:
            if port.hwid.find(supoored_port) != -1:
                supported_port_name = port.name
                break
        if supported_port_name != "":
            break
    
    if len(supported_port_name) != 0:
        if sys.platform.startswith('linux'):
            supported_port_name = "".join(["/dev/", supported_port_name])
        elif sys.platform.startswith("darwin"):
            supported_port_name = "".join(["/dev/", supported_port_name])
        elif sys.platform.startswith('win'):
            supported_port_name = supported_port_name
        
    return supported_port_name

def open_port(port:str):
    serialPort = None
    if port != "":
        serialPort = serial.Serial(
            port=port, \
            baudrate=3000000, \
            bytesize=8, \
            stopbits=serial.STOPBITS_ONE,\
            timeout=0)
    return serialPort

def close_port(serialPort):
    serialPort.close()

def listen_port(port, image_queue):
    print(f"Opening port {port}")
    reader = open_port(port)
    input_buffer = collections.deque(maxlen=INPUT_BUFFER_SIZE)
    print(f"Listening port {port}")
    image = Image()
    close_reader = False
   
    while True:
        res = reader.read(8192)
        for byte in res:
            input_buffer.append(byte)

        for iter in range(20):
            if len(input_buffer) < MIN_MESSAGE_LENGTH:
                break
            message = Message()
            message.find_message(input_buffer)
            if message.is_message_found:
                if message.messageType == MessageType.IMAGE_META:
                    payload = ImageMetaPayloadDecoder(message.payload)
                    image.id = payload.image_id
                    image.hight = payload.image_hight
                    image.width = payload.image_width
                    image.total_chunk_number = payload.package_total_number
                    image.chunk_size = payload.package_size
                elif message.messageType == MessageType.IMAGE:
                    payload = ImagePayloadDecoder(message.payload)
                    if payload.image_id != image.id:
                        image.clear()
                        image.id = payload.image_id
                    image.add_chunk(payload.chunk_id, payload.image)
                    pass
                elif message.messageType == MessageType.RESET_RECEIVER:
                    #input_buffer.clear()
                    frame = image.get_image()
                    if frame.shape != (0,0):
                        frame = cv2.cvtColor(frame, cv2.COLOR_BayerRG2BGR)
                        print(f"{datetime.datetime.now()}: Decode picture {image.id}")
                        image.clear()
                        image_queue.put(frame)                    
                    pass
                elif message.messageType == MessageType.UNDEFINED:
                    input_buffer.popleft()
                    pass
                elif message.messageType == MessageType.CLOSE_STREAM:
                    close_reader = True                   
                else:
                    # unknown value
                    pass 
                pass    
            pass

        if close_reader:
            break
        pass
    close_port(reader)
    input_buffer.clear()
    print("Port listner is closed.")
    
def show_stream_content(frame):
    try:
        cv2.imshow('Stream', frame)
        cv2.waitKey(25)

    except Exception as ex:
        print(f"{str(ex)}")

def main():
    
    system_ports = get_system_ports()
    port = get_supported_port(system_ports)

    if len(port) > 1: 
            
        image_queue = queue.Queue()

        content_listener = threading.Thread(target=listen_port, args=(port, image_queue))
        content_listener.start()

        while True:
            if not image_queue.empty():
                image = image_queue.get()
                show_stream_content(image)
            if not content_listener.is_alive():
                break
    else:
        print(f"Error! Port was not found!")

if __name__ == "__main__":
    main()