###############################################################################
# IMPORTS OF LIBS
###############################################################################

import os.path
import shutil
import datetime
import csv
import math

import argparse

import image_processing
from data_types import OperationResult, InputConfig
from bin_decoder import BinDecoder, DataPackage, FileMeta, PackageType

###############################################################################
# FUNCTIONS
###############################################################################

def read_input_arguments()-> InputConfig:
    operation_result = OperationResult.SUCCSES

    argParser = argparse.ArgumentParser()

    argParser.add_argument("-b", "--bin", action="store_false", help="disable copy of the source bin file to destination folder")
    argParser.add_argument("source", type=str, help="path to the source folder or to the source binary file")
    argParser.add_argument("destination", type=str, help="path to the destination folder")

    args = argParser.parse_args()
    config = InputConfig(args.source, args.destination, args.bin)

    return config

def get_folder_content(source_folder:str):
    res = []
    content_list = sorted(os.listdir(source_folder))
    for file_path in content_list:
        # check if current file_path is a file
        full_file_path = os.path.join(source_folder, file_path)
        if os.path.isfile(full_file_path):
            # add filename to list
            res.append(full_file_path)
            pass
        pass
    return res

def process_frame_package(video_file_writer, map_file_writer, package:DataPackage, meta:FileMeta):
    # get frame package fields
    frame = package.package_content.image
    timemark = package.package_content.time_mark
    timemark_copy = package.package_content.time_mark_copy

    if process_frame_package.frame_counter == 0:
        process_frame_package.start_time_mark = timemark
        process_frame_package.time_scale_step_ms = int(1000 / meta.fps)
        process_frame_package.lost_frames = 0
        process_frame_package.last_video_frame = None
        process_frame_package.is_image_damaged = 0

        # decode frame to RGB, write to the video file
        video_frame = image_processing.format_file_content(frame, meta.image_width, meta.image_hieght)

        # store frame to the video file
        video_file_writer.write(video_frame)  
        process_frame_package.frame_counter += 1
        process_frame_package.last_video_frame = video_frame

    else:        
        # check losing frame
        if timemark != timemark_copy:
            print("detected timemark difference")
            # timemark correction operation
            timemark_dif = timemark - process_frame_package.last_frame_timemark
            timemark_copy_dif = timemark_copy - process_frame_package.last_frame_timemark

            if timemark_dif > 0 and timemark_copy_dif > 0 and timemark_dif > timemark_copy_dif:
                timemark = timemark_copy
            elif timemark_dif < 0 and timemark_copy_dif > 0:
                timemark = timemark_copy
            elif timemark_dif < 0 and timemark_copy_dif < 0:
                # both timemarks are broken 
                timemark = process_frame_package.last_frame_timemark + process_frame_package.time_scale_step_ms
        
        time_dif = timemark - process_frame_package.last_frame_timemark

        if time_dif > 1.2*process_frame_package.time_scale_step_ms:
            # insert last frame to close the framerate hole
            losed_frames = math.floor((time_dif)/process_frame_package.time_scale_step_ms)-1
            #print(f"{time_dif} / {process_frame_package.time_scale_step_ms} = {losed_frames}")
            
            for losed_frame in range(1, losed_frames+1, 1):
                # add lossed frame
                video_file_writer.write(process_frame_package.last_video_frame)
                # add frame timemark
                data = [process_frame_package.frame_counter + losed_frame, -1]
                map_file_writer.writerow(data) 

            process_frame_package.lost_frames += losed_frames
            process_frame_package.frame_counter += losed_frames

        # correction image data size
        expected_image_length = meta.image_hieght * meta.image_width
        content_length = len(frame)
        if content_length > expected_image_length:
            frame = frame[:expected_image_length]
            process_frame_package.is_image_damaged = 1
        elif content_length < expected_image_length:
            len_dif = expected_image_length - content_length
            support_sequence = bytearray(len_dif) 
            frame += support_sequence
            process_frame_package.is_image_damaged = 2
        else:
            process_frame_package.is_image_damaged = 0

        # decode frame to RGB, write to the video file
        video_frame = image_processing.format_file_content(frame, meta.image_width, meta.image_hieght)
        
        if video_frame is not None:
            video_file_writer.write(video_frame)  
            process_frame_package.last_video_frame = video_frame
            process_frame_package.frame_counter += 1
        
    process_frame_package.last_frame_timemark = timemark
    
    if DEBUG_MODE and FRAME_STORE_ENABLE:
        folder_to_store_bin_content = os.path.join(BASE_STORE_PATH, "bin")
        folder_to_store_image_content = os.path.join(BASE_STORE_PATH, "png")
        image_processing.store_frame_to_binary_file(folder_to_store_bin_content, f"frame_{process_frame_package.frame_counter}.bin", frame)
        image_processing.store_frame_to_file(folder_to_store_image_content, f"frame_{process_frame_package.frame_counter}.png", video_frame)
    
    # add frame timemark
    data = [process_frame_package.frame_counter, process_frame_package.last_frame_timemark, process_frame_package.is_image_damaged]
    map_file_writer.writerow(data) 

    return process_frame_package.frame_counter, process_frame_package.lost_frames, process_frame_package.start_time_mark, process_frame_package.last_frame_timemark

def process_mpu_package(meta_file_writer, package:DataPackage, video_time_mark:int):
    timemark = package.package_content.time_mark
    # protect from the wrong data storing
    if timemark < 90*60*1000: # binary file cannot be longer then 90 min
        giro_x = package.package_content.giro_x
        giro_y = package.package_content.giro_y
        giro_z = package.package_content.giro_z
        accel_x_mg = package.package_content.acceleration_x
        accel_y_mg = package.package_content.acceleration_y
        accel_z_mg = package.package_content.acceleration_z
        # write meta data to the csv file
        data = [timemark, giro_x, giro_y, giro_z, accel_x_mg, accel_y_mg, accel_z_mg]
        meta_file_writer.writerow(data) 
    
def decode_video_file_content(filepath:str, destination_videofile:str, destination_metafile:str, destination_map_file:str) -> int:

    operation_result = 0

    file_reader = open(filepath, 'rb')
    file_decoder = BinDecoder(file_reader)

    print(f"\nStart decoding of the {filepath}")

    # check if file has correct content
    if file_decoder.source_content_valid == False:
        print(f"{file_decoder.error_msg}")
        return 1  
    
    # create and prepare output file with mpu data
    meta_file = open(destination_metafile, 'a', newline='') 
    meta_file_fields = ['timemark, ms', 'giro_x, 100x */s', 'giro_y, 100x */s', 'giro_z, 100x */s', "accel_x, mg", "accel_y, mg", "accel_z, mg"]
    meta_file_writer = csv.writer(meta_file, delimiter = '\t')
    meta_file_writer.writerow(meta_file_fields)

    # create and prepare output file with video data
    meta = file_decoder.get_meta_info()
    video_file_writer = image_processing.create_video_writer(destination_videofile, meta.fps, (meta.image_width, meta.image_hieght))
    
    # create frame map file
    map_file = open(destination_map_file, 'w', newline='')
    map_file_writer = csv.writer(map_file, delimiter = '\t')
    map_file_fields = ['frame number', 'timemark, ms', 'damage code']
    map_file_writer.writerow(map_file_fields)

    # start decoding process
    lost_frames = 0
    frame_counter = 0
    first_frame_timemark = 0
    last_frame_timemark = 0

    process_frame_package.frame_counter = 0
    process_frame_package.last_timer_value = 1
    while True:

        status, packages = file_decoder.get_packages()

        for package in packages:
            if package.package_type == PackageType.FRAME:
                frame_counter, lost_frames, first_frame_timemark, last_frame_timemark = process_frame_package(video_file_writer, map_file_writer, package, meta)
            elif package.package_type == PackageType.MPU:
                process_mpu_package(meta_file_writer, package, first_frame_timemark)

            """
            timer = (last_frame_timemark - first_frame_timemark)/1000
            if frame_counter > 0:
                losed_frames_in_persentage = round(lost_frames / frame_counter * 100, 2)
            else:
                losed_frames_in_persentage = 0

            if timer/process_frame_package.last_timer_value >= 1:
                process_frame_package.last_timer_value += 1
                print(f"{(last_frame_timemark - first_frame_timemark)/1000} s : {lost_frames}; {losed_frames_in_persentage}%")
            """

        if status == False:
            break

    meta_file.close()
    map_file.close()
    video_file_writer.release()
    

    print(f"{frame_counter} frames where decoded.")
    print(f"Record length is {(last_frame_timemark - first_frame_timemark)/1000} s")
    if frame_counter != 0:
        print(f"{lost_frames} frames were lost! Lost {round(lost_frames / frame_counter * 100, 2)}%.\n")
    else:
        print(f"{lost_frames} frames were lost! Lost 0%.\n")

    return operation_result

def decode_video_files(config:InputConfig):
    file_list = []

    # check source config: is it file or folder
    if os.path.exists(config.source_path):
        if os.path.isfile(config.source_path):
            file_list.append(config.source_path)
            pass
        else:
            file_list = get_folder_content(config.source_path)
            pass
        pass

    # prepare destination folder
    destination_folder_name = datetime.datetime.now().strftime("%Y-%m-%d__%H-%M-%S")
    session_folder_name =  os.path.join(config.destination_path, destination_folder_name)
    os.makedirs(session_folder_name)

    # run decoder for each file in source
    for source_file in file_list:
        file_name = os.path.basename(source_file)

        destination_videofile = os.path.join(session_folder_name, "".join([f"{file_name}_frames",".avi"]))
        destination_metafile = os.path.join(session_folder_name, "".join([f"{file_name}_mpu",".csv"]))
        destination_map_file = os.path.join(session_folder_name, "".join([f"{file_name}_frame_map",".csv"]))

        operation_error = decode_video_file_content(source_file, destination_videofile, destination_metafile, destination_map_file)
        if not operation_error and config.source_file_copy:
            print("Starting copying the source file...")
            shutil.copyfile(source_file, os.path.join(session_folder_name, file_name))
            print("Source file was copied successfully.")
            pass
        pass
    pass
        
def clear_debug_folder(base_folder_path:str):
    import shutil
    if os.path.exists(base_folder_path):
        for filename in os.listdir(base_folder_path):
            file_path = os.path.join(base_folder_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                print('Failed to delete %s. Reason: %s' % (file_path, e))
###############################################################################
# SCRIPT
###############################################################################
DEBUG_MODE = False
FRAME_STORE_ENABLE = False

if not DEBUG_MODE:
    input_config = read_input_arguments()
else:
    source_path = ""
    destination_folder = ""

    if FRAME_STORE_ENABLE:
        BASE_STORE_PATH = ""
        clear_debug_folder(BASE_STORE_PATH)
        os.makedirs(os.path.join(BASE_STORE_PATH, "bin"), exist_ok=True)
        os.makedirs(os.path.join(BASE_STORE_PATH, "png"), exist_ok=True)

    input_config = InputConfig(source_path, destination_folder, source_file_copy=False)

if input_config.check_input_config() is OperationResult.SUCCSES:
    decode_video_files(input_config)
    print("Done.")
else:
    print("Done with errors.")

