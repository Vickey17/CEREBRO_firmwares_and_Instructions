from enum import Enum
import os.path

class OperationResult(Enum):
    SUCCSES = 0
    ERROR = 1
    CRITICAL_ERROR = 2

class InputConfig():
    def __init__(self, source:str, destination:str, source_file_copy:bool=True) -> None:
        self.source_path = source
        self.destination_path = destination
        self.source_file_copy = source_file_copy
        pass

    def check_input_config(self)->OperationResult:

        result = OperationResult.SUCCSES

        # checking source path
        if not os.path.exists(self.source_path):
            result = OperationResult.CRITICAL_ERROR
            pass
        
        return result
    pass

