import re 
from enum import Enum
from typing import List

import logging

logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.WARNING)

TAG_SIZE = 4
TIMEMARK_SIZE = 4

class BinBuffer:

    def __init__(self) -> None:
        self.buffer = b''
        pass

    def get_content(self) -> bytes:
        return self.buffer
    
    def add_content(self, content:bytes) -> None:
        if content is not None:
            self.buffer += content

    def get_length(self) -> int:
        return len(self.buffer)
    
    def remove_content(self, length:int) -> None:
        self.buffer = self.buffer[length:]

class FileMeta():
    max_meta_info_length = 50
    init_done = False

    def __init__(self, content:bytes) -> None:

        res = re.search(r"Image:(\d{1,5})x(\d{1,5});FPS:(\d{1,4});", content.decode("utf-8", errors="ignore"))
        if res is not None:
            self.image_width = int(res.group(1))
            self.image_hieght = int(res.group(2))
            self.fps = int(res.group(3))/10

            self.meta_info_size = res.regs[0][1]
            self.color_depth = 1
            self.init_done = True
        pass

class PackageType(Enum):
    MPU = 'mpu_'
    FRAME = 'frm_'

class PackageDecodeStatus(Enum):
    STATUS_UNKNOWN = 0
    CONTENT_NOT_RECOGNIZED = 10
    CONTENT_NOT_FULL = 11
    PACKAGE_DECODED = 20

class MpuPackage:
    def __init__(self) -> None:
        self.package_size:int = TAG_SIZE + TIMEMARK_SIZE + 4 * 6 + TAG_SIZE
        self.package_decoded:bool = False

        self.timemark:int = 0
        self.giro_x:int = 0
        self.giro_y:int = 0
        self.giro_z:int = 0
        self.acceleration_x:int = 0
        self.acceleration_y:int = 0
        self.acceleration_z:int = 0
        pass

    def decode_package(self, bin_content)->PackageDecodeStatus:

        decode_status = PackageDecodeStatus.STATUS_UNKNOWN

        if len(bin_content) >= self.package_size:
            self.time_mark:int = int.from_bytes(bin_content[TAG_SIZE:TAG_SIZE+TIMEMARK_SIZE], 'little')
            self.giro_x:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE:TAG_SIZE+TIMEMARK_SIZE+4], 'little', signed=True)
            self.giro_y:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE+4:TAG_SIZE+TIMEMARK_SIZE+8], 'little', signed=True)
            self.giro_z:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE+8:TAG_SIZE+TIMEMARK_SIZE+12], 'little', signed=True)
            self.acceleration_x:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE+12:TAG_SIZE+TIMEMARK_SIZE+16], 'little', signed=True)
            self.acceleration_y:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE+16:TAG_SIZE+TIMEMARK_SIZE+20], 'little', signed=True)
            self.acceleration_z:int = int.from_bytes(bin_content[TAG_SIZE+TIMEMARK_SIZE+20:TAG_SIZE+TIMEMARK_SIZE+24], 'little', signed=True)
            self.package_decoded = True
            decode_status = PackageDecodeStatus.PACKAGE_DECODED
        else:
            self.package_decoded = False
            decode_status = PackageDecodeStatus.CONTENT_NOT_FULL
        
        return decode_status

class FramePackage:

    def __init__(self, frame_width, frame_hight, color_depth) -> None:
        self.frame_size = frame_width * frame_hight * color_depth
        self.package_size:int = TAG_SIZE + TIMEMARK_SIZE + self.frame_size + TIMEMARK_SIZE + TAG_SIZE
        self.package_decoded:bool = False

        self.timemark:int = 0
        self.image:bytes = None
        pass

    def decode_package(self, bin_content)->PackageDecodeStatus:

        decode_status = PackageDecodeStatus.STATUS_UNKNOWN
        
        if len(bin_content) >= self.package_size:
            self.time_mark = int.from_bytes(bin_content[TAG_SIZE:TAG_SIZE+TIMEMARK_SIZE], 'little')
            self.image = bin_content[TAG_SIZE+TIMEMARK_SIZE:self.package_size-TIMEMARK_SIZE-TAG_SIZE]
            self.time_mark_copy = int.from_bytes(bin_content[self.package_size-TIMEMARK_SIZE-TAG_SIZE:self.package_size-TAG_SIZE], 'little')
            decode_status = PackageDecodeStatus.PACKAGE_DECODED
            self.package_decoded = True
        else:
            self.package_decoded = False
            decode_status = PackageDecodeStatus.CONTENT_NOT_FULL

        return decode_status

class DataPackage:
    def __init__(self, file_meta:FileMeta, package_type:PackageType, bin_content:bytes) -> None:
        self.package_type = package_type
        self.decoding_status:PackageDecodeStatus = PackageDecodeStatus.STATUS_UNKNOWN
        self.package_content = None

        package = None
        if package_type == PackageType.MPU:
            package = MpuPackage()
        elif package_type == PackageType.FRAME:
            package = FramePackage(file_meta.image_width, file_meta.image_hieght, file_meta.color_depth)
        else:
            package = None
            pass
        
        if package is not None:
            # check second tag and package length
            search_shift = package.package_size - TAG_SIZE
            tags_index = bin_content[search_shift:].find(bytes(package_type.value, 'utf-8'))

            if tags_index != -1:
                tags_position = search_shift + tags_index
                if (tags_position + TAG_SIZE) != package.package_size:
                    dif = abs(package.package_size - (tags_position + TAG_SIZE))
                    if dif > 2:
                        self.decoding_status = PackageDecodeStatus.CONTENT_NOT_RECOGNIZED
                        logging.debug(f"Wrong tag {package_type} found. Difference is {dif}")
                    else:
                        package.package_size = (tags_index + TAG_SIZE)
                        logging.debug(f"Corrupted package is found. Tag {package_type}. New length is {package.package_size}")
                
                if self.decoding_status == PackageDecodeStatus.STATUS_UNKNOWN:
                    self.decoding_status = package.decode_package(bin_content)
            elif len(bin_content) < package.package_size:
                self.decoding_status = PackageDecodeStatus.CONTENT_NOT_FULL

            if self.decoding_status == PackageDecodeStatus.PACKAGE_DECODED:
                self.package_content = package
            elif self.decoding_status == PackageDecodeStatus.CONTENT_NOT_FULL:
                pass
            elif self.decoding_status == PackageDecodeStatus.STATUS_UNKNOWN:
                # unknown error should not occure
                logging.error(f"ERROR! package decode return UNKNOWN status ") 
        else:
            logging.error(f"ERROR! package decode got UNKNOWN package type ")

    def get_package_bin_length(self) -> int:
        length = 0
        if self.package_content is not None:
            length = self.package_content.package_size

        return length

class BinDecoder:
    
    source_content_valid:bool = False
    error_msg:str = ""

    def __init__(self, source_content_reader) -> None:
        self.bin_buffer = BinBuffer()
        self.content_reader = source_content_reader
        self.content_is_over:bool = False

        cotent = self._read_content(FileMeta.max_meta_info_length)

        self.file_meta = FileMeta(cotent)
        if self.file_meta.init_done:
            self.source_content_valid = True
            self._mark_content_as_analyzed(self.file_meta.meta_info_size)
        else:
            self.error_msg = "Wrong metadata segment. "

    def _read_content(self, count)->bytes:
        content = self.content_reader.read(count)
        if len(content) > 0:
            self.bin_buffer.add_content(content)
        else:
            self.content_is_over = True
        
        return self.bin_buffer.get_content()
    
    def _update_content(self):
        return self.bin_buffer.get_content()
    
    def _mark_content_as_analyzed(self, count):
        self.bin_buffer.remove_content(count)

    def get_meta_info(self)->FileMeta:
        return self.file_meta

    def get_package(self, content:bytes)->DataPackage:

        package = None
        found_tag_indexes = {}
        for package_type in PackageType:
            tag_index = content.find(bytes(package_type.value, 'utf-8'))
            if tag_index != -1:
                found_tag_indexes[package_type] = tag_index

        if len(found_tag_indexes) > 0:
            min_key = min(found_tag_indexes, key=lambda k: found_tag_indexes[k])
        else:
            min_key = None

        if min_key == PackageType.MPU:
            # read mpu package 
            self._mark_content_as_analyzed(found_tag_indexes[min_key])
            content = self._update_content()
            package = DataPackage(self.file_meta, PackageType.MPU, content)
        elif min_key == PackageType.FRAME:
            # read frame package 
            self._mark_content_as_analyzed(found_tag_indexes[min_key])
            content = self._update_content()
            package = DataPackage(self.file_meta, PackageType.FRAME, content)
        else:
            # tag not found
            package = None
        
        return package

    def get_packages(self)->List[DataPackage]:
        packages = list()
        content = self._read_content(256*1024)

        for attempt in range(2048):            
            package = self.get_package(content)
            if package is not None:
                if package.decoding_status == PackageDecodeStatus.PACKAGE_DECODED:
                    packages.append(package)
                    self._mark_content_as_analyzed(package.get_package_bin_length())
                    content = self._update_content()
                elif package.decoding_status == PackageDecodeStatus.STATUS_UNKNOWN or \
                     package.decoding_status == PackageDecodeStatus.CONTENT_NOT_FULL:
                    break
                elif package.decoding_status == PackageDecodeStatus.CONTENT_NOT_RECOGNIZED:
                    self._mark_content_as_analyzed(TAG_SIZE)
                    content = self._update_content()
            else:
                break
        
        return not self.content_is_over, packages
