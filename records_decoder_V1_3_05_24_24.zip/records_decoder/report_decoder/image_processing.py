import numpy as np
import cv2
import os.path

def format_file_content(file_conent:bytes, image_width:int, image_high:int) -> np.ndarray:
    img = None
    try:
        img = np.frombuffer(file_conent, dtype=np.uint8).reshape((image_high, image_width))
        img = cv2.cvtColor(img, cv2.COLOR_BayerRG2BGR_VNG)
    except:
        print("Error: cannot reshape and decode image from bayer to rgb.")
    return img

def create_video_writer(destination_videofile:str, fps:int, image_size:tuple):
    return cv2.VideoWriter(destination_videofile, cv2.VideoWriter_fourcc(*'DIVX'), fps, image_size)

def rotate_image_90(frame:np.ndarray, rotation_count:int):
    return np.rot90(frame, rotation_count)

def store_frame_to_file(filepath:str, filename:str, frame:np.ndarray):
    if os.path.exists(filepath) and frame is not None:
        destination_path = os.path.join(filepath, filename)
        cv2.imwrite(destination_path, frame)
    else:
        raise Exception("Error when storing image to file.")

def store_frame_to_binary_file(filepath:str, filename:str, frame:bytes):
    if os.path.exists(filepath) and frame is not None:
        destination_path = os.path.join(filepath, filename)
        binary_file = open(destination_path, "wb")
        binary_file.write(frame)
        binary_file.close()
    else:
        raise Exception("Error when storing image as binary file.")
    
def cut_image_columns(image:np.ndarray, column_index:int, column_number)->np.ndarray:
    image_copy = image.copy()
    for column_counter in range(column_number):
        image_copy = np.delete(image_copy, column_index, axis=1)
    return image_copy

