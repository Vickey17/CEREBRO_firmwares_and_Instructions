# Connect configuration file
. env.config

# Check path to python executable
if [ -z "$python_executable_path" ]
then
      PYTHON_RUN_COMMAND="python3"
else
      PYTHON_RUN_COMMAND=$python_executable_path
fi

# Path to the enviroment folder
ENV_DIR="$(pwd)/env"
ENV_PYTHON="$ENV_DIR/bin/python3"

# Create folder for the new enviroment
mkdir -p $ENV_DIR

# Run new enviroment
$PYTHON_RUN_COMMAND ./environment_builder/extended_env_builder.py $ENV_DIR --clear --verbose

# install required libs
$ENV_PYTHON -m pip install -r ./environment_builder/requirements.txt
