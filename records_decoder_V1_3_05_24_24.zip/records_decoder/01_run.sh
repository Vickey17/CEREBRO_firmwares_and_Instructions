# Path to the enviroment folder
ENV_DIR="$(pwd)/env"
ENV_PYTHON="$ENV_DIR/bin/python3"

if [ -d "$ENV_DIR" ]; then
    echo ""
else
   ./00_prepare_env.sh
fi

$ENV_PYTHON ./report_decoder/main.py $@
